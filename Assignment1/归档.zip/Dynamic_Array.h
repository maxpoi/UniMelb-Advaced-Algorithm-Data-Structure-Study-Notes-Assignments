Data_Element* insert_dynamic_array(Data_Element *arr, Data_Element data,
                                    int *num, int *size);
Data_Element* delete_dynamic_array(Data_Element *arr, Data_Element data,
                                    int *num, int *size);
Data_Element search_dynamic_array(Data_Element *arr, int key, int num);