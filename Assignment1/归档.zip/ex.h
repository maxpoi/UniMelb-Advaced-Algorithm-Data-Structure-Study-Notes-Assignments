void ex1(int num_trails);
void ex2(double prob, int MAX_LEN);
void ex3(double prob, int MAX_LEN);
void ex4(int num_trails, double mixed_percentage);