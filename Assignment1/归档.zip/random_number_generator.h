#define RANDOM_MAX 10000000

int generate_random_number(int range);